<?php
namespace App\Repositories\Associate;

interface AssociateRepositoryContract
{
    
    public function find($id);
    
    public function getAllAssociate();

    public function create($requestData);

    public function update($id, $requestData);
}
