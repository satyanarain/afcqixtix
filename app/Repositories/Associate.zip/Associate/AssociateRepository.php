<?php
namespace App\Repositories\Associate;

use App\Models\Associate;
use App\Models\AssociateAddress;
use App\Models\Tasks;
use App\Models\Settings;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use Gate;
use Datatables;
use Carbon;
use Notifynder;
use PHPZen\LaravelRbac\Traits\Rbac;
use App\Models\Role;
use Auth;
use Illuminate\Support\Facades\Input;
use App\Models\Client;
use App\Models\Department;
use DB;
use Illuminate\Support\Facades\Mail;
use App\Mail\UserCreated;

class AssociateRepository implements AssociateRepositoryContract
{

    public function find($id)
    {
	   return Associate::findorFail($id);   
    }

    public function getAllAssociate()
    {
        return Associate::all();
    }
    
    
    public function getAllAssociateCount(){
    	return Associate::where('group_company_id', 'like', '%'.session('companyId').'%')->get()->count();
    }



    public function create($requestData)
    {
        
        $settings = Settings::first();
        $companyname = $settings->company;

        $countries = $requestData->country;

        $countries = implode(',', $countries);

        //echo json_encode($countries);exit();
        $input = $requestData->all();
        $input['country'] = $countries;
        //echo json_encode($input);exit();
        if ($requestData->hasFile('image')) {
            if (!is_dir(public_path(). '/images/'. $companyname)) {
                mkdir(public_path(). '/images/'. $companyname, 0777, true);
            }
            
            $file =  $requestData->file('image');

            $destinationPath = public_path(). '/images/'. $companyname;
            $filename = str_random(8) . '_' . $file->getClientOriginalName() ;

            $file->move($destinationPath, $filename);
            
            $input =  array_replace($input, ['image'=>"$filename"]);
        }

        $associate = Associate::create($input);

        if($associate){
            $addresses = $requestData->address;
            $data = array();
            foreach ($addresses as $key => $value) {
                $address_input['associate_id'] = $associate->id;
                $address_input['address'] = $value;
                $data[] = $address_input;
            }

            AssociateAddress::insert($data);
        }

        //echo json_encode($associate);exit();

        Session::flash('flash_message', 'Associate successfully added!'); //Snippet in Master.blade.php
        return $associate;
    }

    public function update($id, $requestData)
    {   
        $settings = Settings::first();
        $companyname = $settings->company;
        //echo json_encode($requestData->all());exit();
        $countries = $requestData->country;
        $countries = implode(',', $countries);


        $input = $requestData->all();
        $input['country'] = $countries;

        if ($requestData->hasFile('image')) {
            if (!is_dir(public_path(). '/images/'. $companyname)) {
                mkdir(public_path(). '/images/'. $companyname, 0777, true);
            }
            
            $file =  $requestData->file('image');

            $destinationPath = public_path(). '/images/'. $companyname;
            $filename = str_random(8) . '_' . $file->getClientOriginalName() ;

            $file->move($destinationPath, $filename);
            
            $input =  array_replace($input, ['image'=>"$filename"]);
        }

        $associate = Associate::findorFail($id);

        $associate->fill($input)->save();

        //update address

        $affectedRows = AssociateAddress::where('associate_id', '=', $associate->id)->delete();

        if($associate){
            $addresses = $requestData->address;
            $data = array();
            foreach ($addresses as $key => $value) {
                $address_input['associate_id'] = $associate->id;
                $address_input['address'] = $value;
                $data[] = $address_input;
            }
            
            AssociateAddress::insert($data);
        }
        
        Session::flash('flash_message', 'Associate successfully updated!');

        return $associate;
    }

}
